import numpy as np
import scipy.signal


class ConvLayer(object):
    def __init__(self, n_i, n_o, h):
        """
        Convolutional layer

        Parameters
        ----------
        n_i : integer
            The number of input channels
        n_o : integer
            The number of output channels
        h : integer
            The size of the filter
        """
        # glorot initialization
        f_in = n_i * h * h
        f_out = n_o * h * h
        div_term = np.divide(2, f_in + f_out, dtype=float)
        std_dev = np.sqrt(div_term)
        self.W = np.random.normal(0, std_dev, (n_o, n_i, h, h))
        self.b = np.zeros((1, n_o))

        self.n_i = n_i
        self.n_o = n_o

        self.W_grad = None
        self.b_grad = None
        self.x = None

    def forward(self, x):
        """
        Compute "forward" computation of convolutional layer

        Parameters
        ----------
        x : np.array
            The input data of size number of training samples x number
            of input channels x number of rows x number of columns

        Returns
        -------
        np.array
            The output of the convolutiona

        Stores
        -------
        self.x : np.array
             The input data (need to store for backwards pass)
        """
        self.x = x
        input_shape = x.shape
        batch_size = input_shape[0]
        n_rows = input_shape[2]
        n_cols = input_shape[3]
        ofmap = np.zeros((batch_size, self.n_o, n_rows, n_cols),dtype=float)
        for b in range(batch_size):
            for m in range(self.n_o):
                for c in range(self.n_i):
                    weights = np.flip(self.W[m,c,:,:])
                    ofmap[b, m , :, :] += scipy.signal.convolve(x[b,c,:,:], weights, 'same')

        for b in range(batch_size):
            for m in range(self.n_o):
                ofmap[b, m, :, :] += self.b[0,m]

        return ofmap

    def backward(self, y_grad):
        """
        Compute "backward" computation of convolutional layer

        Parameters
        ----------
        y_grad : np.array
            The gradient at the output

        Returns
        -------
        np.array
            The gradient at the input

        Stores
        -------
        self.b_grad : np.array
             The gradient with respect to b (same dimensions as self.b)
        self.w_grad : np.array
             The gradient with respect to W (same dimensions as self.W
        """
        input_shape = self.x.shape
        batch_size = input_shape[0]
        n_rows = input_shape[2]
        n_cols = input_shape[3]
        fy = self.W.shape[3] # rows_weights
        # p is padding_one_side
        p = (np.ceil(np.divide(fy-1,2.,dtype=float))).astype(int)
        ifmap = np.zeros((batch_size, self.n_i, n_rows, n_cols),dtype=float)
        for b in range(batch_size):
            for c in range(self.n_i):
                for m in range(self.n_o):
                    weights = self.W[m,c,:,:]
                    ifmap[b, c, :, :] += scipy.signal.convolve(y_grad[b,m,:,:], weights, 'same')

        weights = np.zeros((self.n_o, self.n_i, fy, fy),dtype=float)
        for b in range(batch_size):
            for m in range(self.n_o):
                for c in range(self.n_i):
                    ofmap = np.flip(y_grad[b,m,:,:])
                    padded_image = np.pad(self.x[b,c,:,:], ((p, p), (p, p)), mode='constant')
                    weights[m, c, :, :] += scipy.signal.convolve(padded_image, ofmap, 'valid')

        self.W_grad = weights

        self.b_grad = np.sum(y_grad, (0, 2, 3))

        return ifmap

    def update_param(self, lr):
        """
        Update the parameters with learning rate lr

        Parameters
        ----------
        lr : floating point
            The learning rate

        Stores
        -------
        self.W : np.array
             The updated value for self.W
        self.b : np.array
             The updated value for self.b
        """
        update_b = lr * self.b_grad
        update_w = lr * self.W_grad
        self.b = self.b - update_b
        self.W = self.W - update_w
