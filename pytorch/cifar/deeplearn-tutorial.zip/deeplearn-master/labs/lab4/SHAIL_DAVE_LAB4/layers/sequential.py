from __future__ import print_function
import numpy as np


class Sequential(object):
    def __init__(self, layers, loss):
        """
        Sequential model

        Implements a sequence of layers

        Parameters
        ----------
        layers : list of layer objects
        loss : loss object
        """
        self.layers = layers
        self.loss = loss

    def forward(self, x, target=None):
        """
        Forward pass through all layers
        
        if target is not none, then also do loss layer

        Parameters
        ----------
        x : np.array
            The input data of size number of training samples x number of features
        target : np.array
            The target data of size number of training samples x number of features (one-hot)

        Returns
        -------
        np.array
            The output of the model
        """
        input_data = x
        for l in range(len(self.layers)):
            out_l = self.layers[l].forward(input_data)
            input_data = out_l
        if target is not None:
            out_l = self.loss.forward(input_data, target)
        return out_l

    def backward(self):
        """
        Compute "backward" computation of fully connected layer

        Returns
        -------
        np.array
            The gradient at the input

        """
        input_data = self.loss.backward()
        for l in reversed(range(len(self.layers))):
            in_l = self.layers[l].backward(input_data)
            input_data = in_l
        return input_data

    def update_param(self, lr):
        """
        Update the parameters with learning rate lr

        Parameters
        ----------
        lr : floating point
            The learning rate
        """
        for l in reversed(range(len(self.layers))):
            self.layers[l].update_param(lr)

    def fit(self, x, y, epochs=10, lr=0.1, batch_size=128):
        """
        Fit parameters of all layers using batches

        Parameters
        ----------
        x : numpy matrix
            Training data (number of samples x number of features)
        y : numpy matrix
            Training labels (number of samples x number of features) (one-hot)
        epochs: integer
            Number of epochs to run (1 epoch = 1 pass through entire data)
        lr: float
            Learning rate
        batch_size: integer
            Number of data samples per batch of gradient descent
        """
        total_samples = x.shape[0]
        total_batches = (np.ceil((1. * total_samples) / batch_size)).astype(int)
        avg_loss_mini_batch = np.zeros((epochs),dtype=float)
        # print('total batches: ', total_batches)
        for it in range(epochs):
            for b in range(total_batches):
                # print('Running epoch: ',it, ' batch: ', b)
                start_idx = b * batch_size
                end_idx = min(total_samples, (b+1)*batch_size)
                x_train = x[start_idx:end_idx,:]
                y_train = y[start_idx:end_idx, :]
                avg_loss_mini_batch[it] += self.forward(x_train, y_train)
                self.backward()
                self.update_param(lr)

        avg_loss_mini_batch /= total_batches
        return avg_loss_mini_batch

    def predict(self, x):
        """
        Return class prediction with input x

        Parameters
        ----------
        x : numpy matrix
            Testing data data (number of samples x number of features)

        Returns
        -------
        np.array
            The output of the model (integer class predictions)
        """
        pred_mat = self.forward(x)
        return np.argmax(pred_mat, axis=1)
