import numpy as np


class MaxPoolLayer(object):
    def __init__(self, size=2):
        """
        MaxPool layer
        Ok to assume non-overlapping regions
        """
        self.locs = None  # to store max locations
        self.size = size  # size of the pooling

    def forward(self, x):
        """
        Compute "forward" computation of max pooling layer

        Parameters
        ----------
        x : np.array
            The input data of size number of training samples x number
            of input channels x number of rows x number of columns

        Returns
        -------
        np.array
            The output of the maxpooling

        Stores
        -------
        self.locs : np.array
             The locations of the maxes (needed for back propagation)
        """
        input_shape = x.shape
        batch_size = input_shape[0]
        n_i = input_shape[1]
        n_rows = input_shape[2]
        n_cols = input_shape[3]
        out_rows = np.floor(np.divide(n_rows*1.,self.size,dtype=float)).astype(int)
        out_cols = np.floor(np.divide(n_cols * 1., self.size, dtype=float)).astype(int)
        downsampled_ofmap = np.zeros((batch_size, n_i, out_rows, out_cols),dtype=float)
        self.locs = np.zeros((batch_size, n_i, n_rows, n_cols),dtype=int)

        for b in range(batch_size):
            for ni in range(n_i):
                for oy in range(out_rows):
                    r1 = oy*self.size
                    r2 = (oy+1)*self.size
                    for ox in range(out_cols):
                        c1 = ox*self.size
                        c2 = (ox+1)*self.size
                        fmap_window = x[b,ni,r1:r2,c1:c2]
                        max_val = np.amax(fmap_window)
                        downsampled_ofmap[b,ni,oy,ox] = max_val
                        # set locations if multiple values are maximum in the window
                        for uu in range(self.size):
                            for vv in range(self.size):
                                if fmap_window[uu,vv] == max_val:
                                    self.locs[b, ni, r1+uu, c1+vv] = 1

        return downsampled_ofmap

    def backward(self, y_grad):
        """
        Compute "backward" computation of maxpool layer

        Parameters
        ----------
        y_grad : np.array
            The gradient at the output

        Returns
        -------
        np.array
            The gradient at the input
        """
        input_shape = y_grad.shape
        batch_size = input_shape[0]
        n_i = input_shape[1]
        out_rows = input_shape[2]
        out_cols = input_shape[3]
        upsampled_image = np.zeros(self.locs.shape,dtype=float)

        for b in range(batch_size):
            for ni in range(n_i):
                for oy in range(out_rows):
                    r1 = oy*self.size
                    r2 = (oy+1)*self.size
                    for ox in range(out_cols):
                        c1 = ox*self.size
                        c2 = (ox+1)*self.size
                        upsampled_image[b,ni,r1:r2,c1:c2] = \
                            np.multiply(self.locs[b,ni,r1:r2,c1:c2], y_grad[b,ni,oy,ox])

        return upsampled_image


    def update_param(self, lr):
        pass
