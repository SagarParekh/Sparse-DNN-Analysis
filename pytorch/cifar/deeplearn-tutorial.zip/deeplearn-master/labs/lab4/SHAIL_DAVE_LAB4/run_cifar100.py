"""
=> Your Name: Shail Dave

In this script, you need to plot the average training loss vs epoch using a learning rate of 0.1 and a batch size of 128 for 15 epochs.

=> Final accuracy on the test set: 0.6366 i.e. 63.66%

"""

from layers import (FullLayer, ReluLayer, SoftMaxLayer, CrossEntropyLayer, Sequential, ConvLayer, MaxPoolLayer, FlattenLayer)
from layers.dataset import cifar100
import numpy as np
import matplotlib.pyplot as plt

class runCifar():

    def __init__(self):
        """
        Wrapper class to evaluate CIFAR model

        Parameters
        ----------

        """
        self.model = Sequential(
            layers=(ConvLayer(3, 16, 3),
                    ReluLayer(),
                    MaxPoolLayer(2),
                    ConvLayer(16, 32, 3),
                    ReluLayer(),
                    MaxPoolLayer(2),
                    FlattenLayer(),
                    FullLayer(8 * 8 * 32, 3),
                    SoftMaxLayer()),
            loss=CrossEntropyLayer())

        seed = 1207827175
        (self.x_train, self.y_train), (self.x_test, self.y_test) = cifar100(seed)

        self.total_epochs = 15
        self.loss_val = np.zeros((self.total_epochs),float)
        self.accuracy_val = 0
        self.learning_rate = 0.1

    def get_accuracy(self, y_pred, y_test):
        """
        :param y_pred: vector of predicted class labels
        :param y_test: vector of actual class labels
        :return: accuracy of the model (in fraction)
        """
        cat_y_test = np.argmax(y_test, axis=1)
        class_correctness = (y_pred == cat_y_test)
        accuracy = 1. * class_correctness.sum() / len(class_correctness)
        return accuracy

    def evaluate_model(self, lr=0.1, batch_size=128):
        # print("training model for learning rate: ",lr)
        loss = self.model.fit(self.x_train, self.y_train, self.total_epochs, lr, batch_size)
        y_pred = self.model.predict(self.x_test)
        accuracy = self.get_accuracy(y_pred, self.y_test)
        self.accuracy_val = accuracy
        print('accuracy is: ', accuracy)
        self.loss_val = loss

    def plt_avg_training_loss(self, show=False):

        vec_poly = range(1, self.total_epochs + 1)
        plot_clr = 'r'

        loss = self.loss_val
        plt.plot(vec_poly, loss, color=plot_clr, label='Avg Training Loss with Learning Rate = ' + str(self.learning_rate))

        plt.legend()
        plt.xlabel('epoch#')
        plt.ylabel('Average Training Loss')
        plt.savefig('results/loss_plot.png')
        if show:
            plt.show()


def main():
    eval = runCifar()
    eval.evaluate_model(0.1, 128)
    eval.plt_avg_training_loss(show=False)


if __name__ == '__main__':
    main()