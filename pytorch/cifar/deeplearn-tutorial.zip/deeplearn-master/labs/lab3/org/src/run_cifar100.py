"""
=> Your Name:

1. In this script, You need to implement the simple neural network using code presented in Section 4.1.
2. Using the network above, plot the average training loss vs epoch for learning rates 0.1, 0.01, 0.3 for 20 epochs.
3. Run the same network with learning rate 10 and observe the result.
4. Report the test accuracy with learning rates 0.1, 0.01, 0.3 and 10 for 20 epochs.

=> After running this script, describe below what you observe when using learning rate 10:


"""