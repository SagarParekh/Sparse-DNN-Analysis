"""
=> Your Name: Shail Dave

1. In this script, You need to implement the simple neural network using code presented in Section 4.1.
2. Using the network above, plot the average training loss vs epoch for learning rates 0.1, 0.01, 0.3 for 20 epochs.
3. Run the same network with learning rate 10 and observe the result.
4. Report the test accuracy with learning rates 0.1, 0.01, 0.3 and 10 for 20 epochs.

=> After running this script, describe below what you observe when using learning rate 10:
During the training of the model with learning rate 10, several run-time warnings were observed
about division by 0, invalid values, and resultant values were NaN. Due to this issue,
model parameters were not updated after a time instance and this resulted in poor accuracy like 20%
I presume that high learning rate caused exploding gradient problem and numerical instablity.

"""
from layers import (FullLayer, ReluLayer, SoftMaxLayer, CrossEntropyLayer, Sequential)
from layers.dataset import cifar100
import numpy as np
import matplotlib.pyplot as plt
import csv

class runCifar():

    def __init__(self):
        """
        Wrapper class to evaluate CIFAR model

        Parameters
        ----------

        """
        self.new_model = Sequential(
            layers=(FullLayer(32 * 32 * 3, 500),
                    ReluLayer(),
                    FullLayer(500, 5),
                    SoftMaxLayer()),
            loss=CrossEntropyLayer())

        seed = 1207827175
        (self.x_train, self.y_train), (self.x_test, self.y_test) = cifar100(seed)

        self.total_epochs = 20
        self.loss_vals = np.empty((0,self.total_epochs),float)
        self.accuracy_vals = []
        self.learning_rates = [0.1, 0.01, 0.3, 10]

    def get_accuracy(self, y_pred, y_test):
        """
        :param y_pred: vector of predicted class labels
        :param y_test: vector of actual class labels
        :return: accuracy of the model (in fraction)
        """
        class_correctness = (y_pred == y_test)
        accuracy = 1. * class_correctness.sum() / len(class_correctness)
        return accuracy

    def evaluate_model(self, lr=0.1):
        print("training model for learning rate: ",lr)
        self.model = self.new_model
        loss = self.model.fit(self.x_train, self.y_train, self.total_epochs, lr).reshape(1,-1)
        y_pred = self.model.predict(self.x_test)
        accuracy = self.get_accuracy(y_pred, self.y_test)
        self.accuracy_vals = np.append(self.accuracy_vals, accuracy)
        self.loss_vals = np.append(self.loss_vals, loss, axis=0)

    def plt_avg_training_loss(self, show=False):

        vec_poly = range(1, self.total_epochs + 1)
        plot_clr = ['r', 'g', 'b', 'k']
        idx = 0

        total_iterations = max(0, len(self.learning_rates)-1)
        for it in range(total_iterations):
            loss = self.loss_vals[it,:]
            plt.plot(vec_poly, loss, color=plot_clr[idx], label='Avg Training Loss with Learning Rate = ' + str(self.learning_rates[it]))
            idx = idx + 1

        plt.legend()
        plt.xlabel('epoch#')
        plt.ylabel('Average Training Loss')
        plt.savefig('results/acc_lr.png')
        if show:
            plt.show()

    def write_accuracy_results(self):

        with open('results/acc_results.csv', 'wb') as csv_file:
            # fields=['learning rate','model accuracy']
            wr = csv.writer(csv_file, delimiter=',', quoting=csv.QUOTE_MINIMAL)
            for it in range(0, len(self.accuracy_vals)):
                wr.writerow([self.learning_rates[it], "{0:.4f}".format(self.accuracy_vals[it])])

def main():
    eval = runCifar()

    for lr in eval.learning_rates:
        eval.evaluate_model(lr)
    eval.plt_avg_training_loss(show=True)

    eval.write_accuracy_results()


if __name__ == '__main__':
    main()
