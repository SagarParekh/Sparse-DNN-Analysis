"""
=> Your Name: Shail Dave

=> observation for evaluating models of better_cifar:
    # for learning rates = [0.1, 0.01, 0.3, 10]
    # Prior accuracy obtained was [0.686 0.696 0.694 0.2]
    # newly obtained accuracies are: [0.712 0.706 0.64  0.2]
    # It appears that with training on smaller dataset,
    # increasing hidden layers do not have significant improvement
    # in accuracy. Additional factor is that residual connections are
    # also absent here. Moreover, adding too many layers (>5) for
    # this small dataset actually worsens the accuracy.

"""
from layers import (FullLayer, ReluLayer, SoftMaxLayer, CrossEntropyLayer, Sequential)
from layers.dataset import cifar100
import numpy as np
import matplotlib.pyplot as plt
import csv

class runCifar():

    def __init__(self):
        """
        Wrapper class to evaluate CIFAR model

        Parameters
        ----------

        """
        self.new_model = Sequential(
            layers=(FullLayer(32 * 32 * 3, 1024),
                    ReluLayer(),
                    FullLayer(1024, 256),
                    ReluLayer(),
                    FullLayer(256, 64),
                    ReluLayer(),
                    FullLayer(64, 16),
                    ReluLayer(),
                    FullLayer(16, 5),
                    SoftMaxLayer()),
            loss=CrossEntropyLayer())

        seed = 1207827175
        (self.x_train, self.y_train), (self.x_test, self.y_test) = cifar100(seed)

        self.total_epochs = 20
        self.loss_vals = np.empty((0,self.total_epochs),float)
        self.accuracy_vals = []
        self.learning_rates = [0.1, 0.01, 0.3, 10]

    def get_accuracy(self, y_pred, y_test):
        """
        :param y_pred: vector of predicted class labels
        :param y_test: vector of actual class labels
        :return: accuracy of the model (in fraction)
        """
        class_correctness = (y_pred == y_test)
        accuracy = 1. * class_correctness.sum() / len(class_correctness)
        return accuracy

    def evaluate_model(self, lr=0.1):
        print("training model for learning rate: ",lr)
        self.model = self.new_model
        loss = self.model.fit(self.x_train, self.y_train, self.total_epochs, lr).reshape(1,-1)
        y_pred = self.model.predict(self.x_test)
        accuracy = self.get_accuracy(y_pred, self.y_test)
        self.accuracy_vals = np.append(self.accuracy_vals, accuracy)
        self.loss_vals = np.append(self.loss_vals, loss, axis=0)

def main():
    eval = runCifar()

    for lr in eval.learning_rates:
        eval.evaluate_model(lr)

    # for learning rates = [0.1, 0.01, 0.3, 10]
    # Prior accuracy obtained was [0.686 0.696 0.694 0.2]
    # newly obtained accuracies are: [0.712 0.706 0.64  0.2]
    # It appears that with training on smaller dataset,
    # increasing hidden layers do not have significant improvement
    # in accuracy. Additional factor is that residual connections are
    # also absent here. Moreover, adding too many layers (>5) for
    # this small dataset actually worsens the accuracy.

    # print(eval.accuracy_vals)


if __name__ == '__main__':
    main()
