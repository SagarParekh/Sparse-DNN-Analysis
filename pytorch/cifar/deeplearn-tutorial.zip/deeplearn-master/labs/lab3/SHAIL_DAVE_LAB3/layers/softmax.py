import numpy as np


class SoftMaxLayer(object):
    def __init__(self):
        """
        Constructor
        """
        self.y = None

    def forward(self, x):
        """
        Implement forward pass of softmax

        Parameters
        ----------
        x : np.array
            The input data of size number of training samples x number of features

        Returns
        -------
        np.array
            The output of the layer

        Stores
        -------
        self.y : np.array
             The output of the layer (needed for backpropagation)
        """
        mat_y_dash = x - np.amax(x)
        mat_exp = np.exp(mat_y_dash)
        reduced_vec = np.sum(mat_exp, axis=1).reshape(-1,1)
        self.y = mat_exp / reduced_vec.astype(float)
        return self.y

    def backward(self, y_grad):
        """
        Compute "backward" computation of softmax

        Parameters
        ----------
        y_grad : np.array
            The gradient at the output

        Returns
        -------
        np.array
            The gradient at the input

        """
        batch_size = self.y.shape[0]
        output_classes = self.y.shape[1]
        prod_mat = np.zeros((batch_size, output_classes), dtype=float)
        for i in range(batch_size):
            diag_mat = np.diag(self.y[i])
            sub_mat = np.dot(self.y[i].reshape(-1,1),self.y[i].reshape(1,-1))
            dz_dy = (diag_mat - sub_mat)
            prod_mat[i,:] = np.dot(y_grad[i,:].reshape(1,-1), dz_dy)
        return prod_mat

    def update_param(self, lr):
        pass  # no learning for softmax layer
